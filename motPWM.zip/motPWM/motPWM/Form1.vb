﻿Imports System.IO
Imports System.IO.Ports
Imports System.Threading

Public Class Form1
    Dim myPort As Array
    Dim returnStr() As String
    Dim incoming As String
    ''    Dim maxAttempt As Integer = 5

    'Dim myDelegate As New myMethodDelegate(AddressOf ShowString)
    Delegate Sub SetTextCallback(ByVal [text] As String)

    Private Sub Form1_Disposed(sender As Object, e As EventArgs) Handles MyBase.Disposed
        SerialPort1.Close()
        SerialPort1.Dispose()

    End Sub 'Added to prevent threading errors during receiveing of data
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        myPort = IO.Ports.SerialPort.GetPortNames()
        Button2.Enabled = False
        Button1.Enabled = False
        TrackBar1.Enabled = False
        TrackBar2.Enabled = False
        ComboBox1.Items.AddRange(myPort)
        Timer1.Enabled = False
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        SerialPort1.PortName = ComboBox1.Text
        SerialPort1.BaudRate = ComboBox2.Text
        'SerialPort1.DataBits = 8
        'SerialPort1.Parity = Parity.None
        'SerialPort1.StopBits = StopBits.One
        'SerialPort1.Handshake = Handshake.None
        SerialPort1.Encoding = System.Text.Encoding.Default 'very important!
        SerialPort1.Open()
        Button2.Enabled = True
        Button3.Enabled = False
        ComboBox1.Enabled = False
        ComboBox2.Enabled = False
        Button1.Enabled = True
        Timer1.Enabled = True


    End Sub

    Private Sub TrackBar1_MouseUp(sender As Object, e As MouseEventArgs) Handles TrackBar1.MouseUp

        SerialPort1.WriteLine("p=" & Label7.Text) 'concatenate with \n
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        Label7.Text = TrackBar1.Value

    End Sub

    Private Sub TrackBar2_MouseUp(sender As Object, e As MouseEventArgs) Handles TrackBar2.MouseUp
        SerialPort1.WriteLine("f=" & Label8.Text) 'concatenate with \n
    End Sub


    Private Sub TrackBar2_Scroll(sender As Object, e As EventArgs) Handles TrackBar2.Scroll
        Label8.Text = TrackBar2.Value

    End Sub
    Sub actualizare()
        Try

            returnStr = Split(incoming, "|")
            If returnStr(0) <> vbNull Then
                Label1.Text = returnStr(0)
            End If
            If returnStr(1) <> vbNull Then
                Label6.Text = returnStr(1)
            End If

            If returnStr(2) <> vbNull Then
                Label4.Text = returnStr(2)
            End If



        Catch ex As Exception
            Return

        End Try

        'End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        'Timer1.Enabled = False
        If Button2.Text = "Control On" Then
            Button2.Text = "Control Off"
            SerialPort1.WriteLine("c=1") 'concatenate with \n
            TrackBar1.Enabled = True
            TrackBar2.Enabled = True
        Else
            Button2.Text = "Control On"
            SerialPort1.WriteLine("c=0") 'concatenate with \n
            TrackBar1.Enabled = False
            TrackBar2.Enabled = False
        End If
        'Timer1.Enabled = True




    End Sub
    Private Sub SerialPort1_DataReceived(sender As System.Object, e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        incoming = ""
        incoming = SerialPort1.ReadLine()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SerialPort1.Close()
        Button3.Enabled = True
        ComboBox1.Enabled = True
        ComboBox2.Enabled = True
        Button1.Enabled = False
        Timer1.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        
        actualizare()


    End Sub
End Class
